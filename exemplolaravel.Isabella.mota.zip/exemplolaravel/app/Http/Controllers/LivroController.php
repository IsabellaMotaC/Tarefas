<?php

namespace App\Http\Controllers;

use App\Models\Livros;
use Illuminate\Http\Request;

class LivroController extends Controller
{
    public function store(Request $request)
    {
        $tarefa = Livros::create([
            'titulo' => $request->titulo,
            'autor' => $request->autor,
            'editora' => $request->editora,
            'genero' => $request->genero,
            'ano_publicacao' => $request->ano_publicacao,
            'descricao' => $request->descricao,
            'isbn' => $request->isbn,
            'selo_editorial' => $request->selo_editorial
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Salvo',
            'data' => $tarefa
        ]);
    }

    public function index()
    {
        $tarefa = Livros::all();

        return response()->json([
            'status' => true,
            'data' => $tarefa
        ]);
    }

    public function search(Request $request){
        $livros = Livros::where('titulo', 'like', '%' . $request->titulo . '%')->get();

        return response()->json([
            'status' => true,
            'data'=> $livros
        ]);
    }

    public function update(Request $request)
    {
        $livros = Livros::find($request->id);

        if ($livros == null) {
            return response()->json([
                'status' => false,
                'message' => 'Livro não encontrado'
            ]);
        }

        if(isset($request->titulo)){
            $livros->titulo = $request->titulo;
        }

        if(isset($request->autor)){
            $livros->autor = $request->autor;
        }

        if(isset($request->descricao)){
            $livros->descricao = $request->descricao;
        }

        if(isset($request->ano_publicacao)){
            $livros->ano_publicacao = $request->ano_publicacao;
        }

        if(isset($request->genero)){
            $livros->genero = $request->genero;
        }

        if(isset($request->editora)){
            $livros->editora = $request->editora;
        }

        if(isset($request->isbn)){
            $livros->isbn = $request->isbn;
        }

        if(isset($request->selo_editorial)){
            $livros->selo_editorial = $request->selo_editorial;
        }

        $livros->update();

        return response()->json([
            'status' => true,
            'message' => 'Atualizado',
            'data'=> $livros
        ]);
    }

    public function delete($id){
        $livros = Livros::find($id);

        if($livros == null){
            return response()->json([
                'status' => false,
                'message' => 'Não encontrado'
            ]);
        }

        $livros->delete();

        return response()->json([
            'status' => true,
            'message' => 'Deletado',
            'data'=> $livros
        ]);
    }

    public function avancada(Request $request){
        if($request->tipo_pesquisa == 'titulo'){
            $livros = Livros::where('titulo', 'like', '%' . $request->pesquisa . '%')->get();
        }

        if($request->tipo_pesquisa == 'autor'){
            $livros = Livros::where('autor', 'like', '%' . $request->pesquisa . '%')->get();
        }

        if($request->tipo_pesquisa == 'isbn'){
            $livros = Livros::where('isbn', 'like', '%' . $request->pesquisa . '%')->get();
        }
        

        return response()->json([
            'status' => true,
            'data'=> $livros
        ]);
    }

}
