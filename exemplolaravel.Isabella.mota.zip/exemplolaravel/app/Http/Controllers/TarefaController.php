<?php

namespace App\Http\Controllers;

use App\Models\Tarefa;
use Illuminate\Http\Request;

class TarefaController extends Controller
{
    public function index()
    {
        $tarefas = Tarefa::all();

        return response()->json([
            'status' => true,
            'data' => $tarefas
        ]);
    }


    public function show($id)
    {
        $tarefa = Tarefa::find($id);

        if ($tarefa == null) {
            return response()->json([
                'status' => true,
                'message' => 'Tarefa não encontrada'
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Tarefa encontrada',
            'data' => $tarefa
        ]);
    }


    public function store(Request $request)
    {
        $tarefa = Tarefa::create([
            'nome' => $request->nome,
            'data_hora' => $request->data_hora,
            'descricao' => $request->descricao
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Salvo',
            'data' => $tarefa
        ]);
    }

    public function update(Request $request)
    {
        $tarefa = Tarefa::find($request->id);

        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'Tarefa não encontrada'
            ]);
        }

        if(isset($request->nome)){
            $tarefa->nome = $request->nome;
        }

        if(isset($request->data_hora)){
            $tarefa->data_hora = $request->data_hora;
        }

        if(isset($request->descricao)){
            $tarefa->descricao = $request->descricao;
        }

        $tarefa->update();

        return response()->json([
            'status' => true,
            'message' => 'Atualizado',
            'data'=> $tarefa
        ]);
    }

    public function delete($id){
        $tarefa = Tarefa::find($id);

        if($tarefa == null){
            return response()->json([
                'status' => false,
                'message' => 'Não encontrado'
            ]);
        }

        $tarefa->delete();

        return response()->json([
            'status' => true,
            'message' => 'Deletado',
            'data'=> $tarefa
        ]);
    }

    public function search(Request $request){
        $tarefas = Tarefa::where('nome', 'like', '%' . $request->nome . '%')->get();

        return response()->json([
            'status' => true,
            'data'=> $tarefas
        ]);
    }
}
