<?php

use App\Http\Controllers\LivroController;
use App\Http\Controllers\TarefaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


Route::get('/tarefa', [TarefaController::class, 'index']);

Route::get('/tarefa/find/{id}', [TarefaController::class, 'show']);

Route::post('/tarefa', [TarefaController::class, 'store']);

Route::put('/tarefa', [TarefaController::class, 'update']);

Route::delete('/tarefa/delete/{id}', [TarefaController::class, 'delete']);

Route::get('/tarefa/search', [TarefaController::class, 'search']);


// TAREFA LIVROS //

Route::post('/livro', [LivroController::class, 'store']);

Route::get('/livro', [LivroController::class, 'index']);

Route::get('/livro/search', [LivroController::class, 'search']);

Route::put('/livro', [LivroController::class, 'update']);

Route::delete('/livro/delete/{id}', [LivroController::class, 'delete']);

Route::get('/livro/search/2', [LivroController::class, 'avancada']);
