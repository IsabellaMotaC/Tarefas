<?php

namespace App\Http\Controllers;

use App\Http\Requests\ClienteFormRequest;
use App\Http\Requests\ClienteUpdateFormRequest;
use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    public function store (ClienteFormRequest $request){
        $clientes = Cliente::create([
            'nome' => $request->nome,
            'email' => $request->email,
            'telefone' => $request->telefone,
            'endereco' => $request->endereco
        ]);

        return response()->json([
            'status' => true,
            'message' => 'cadastrado com sucesso',
            'data' => $clientes
        ]);
    }

    public function index()
    {
        $clientes = Cliente::all();

        return response()->json([
            'status' => true,
            'data' => $clientes
        ]);
    }

        public function show($id){
            $clientes = Cliente::find($id);

            if($clientes == null){
                return response()->json([
                    'status' => false,
                    'message' => 'Não foi possível fazer a busca'
                ]);
            }

            return response()->json([
                'status' => true,
                'data' => $clientes
            ]);
        }
        
        public function update(ClienteUpdateFormRequest $request)
    {
        $clientes = Cliente::find($request->id);

        if ($clientes == null) {
            return response()->json([
                'status' => false,
                'message' => 'Cliente não encontrado'
            ]);
        }

        if(isset($request->nome)){
            $clientes->nome = $request->nome;
        }

        if(isset($request->email)){
            $clientes->email = $request->email;
        }
        
        if(isset($request->telefone)){
            $clientes->telefone = $request->telefone;
        }

        if(isset($request->endereco)){
            $clientes->endereco = $request->endereco;
        }

        $clientes->update();

        return response()->json([
            'status' => true,
            'message' => 'Atualizado',
            'data'=> $clientes
        ]);
    }

    public function destroy($id){
        $clientes = Cliente::find($id);

        if($clientes == null){
            return response()->json([
                'status' => false,
                'message' => 'Não encontrado'
            ]);
        }

        $clientes->delete();

        return response()->json([
            'status' => true,
            'message' => 'Deletado',
            'data'=> $clientes
        ]);
    }
    
}
