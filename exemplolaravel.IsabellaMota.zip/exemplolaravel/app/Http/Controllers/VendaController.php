<?php

namespace App\Http\Controllers;

use App\Models\Venda;
use Illuminate\Http\Request;

class VendaController extends Controller
{
    public function store(Request $request){

        $subtotal = 0;
        foreach($request ->itens as $item){
            $subtotal +=$item['quantidade']*$item['preco'];
        }

        $vendas = Venda::create([
            'cliente_id' => $request->cliente_id,
            'data_venda' => date('Y-m-d H:i:s'),
            'desconto' => $request->desconto,
            'total' => 0
            
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Venda cadastrada com sucesso',
            'data' => $vendas
        ]);
    }

    public function index(){
        $vendas = Venda::get();

        return response()->json([
            'status' => true,
            'message' => 'Resultado de Vendas',
            'data' => $vendas
        ]);
    }

    public function show($id){
        $vendas = Venda::find($id);

        if($vendas == null){
            return response()->json([
                'status' => false,
                'message' => 'Venda não encontrada',
           
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Venda Encontrada',
            'data' => $vendas
        ]);


    }

    public function update(Request $request)
    {
        $vendas = Venda::find($request->id);

        if ($vendas == null) {
            return response()->json([
                'status' => false,
                'message' => 'Venda não encontrado'
            ]);
        }

   
        if(isset($request->nome)){
            $vendas->nome = $request->nome;
        }
        if(isset($request->codigo)){
            $vendas->codigo = $request->codigo;
        }
        if(isset($request->preco)){
            $vendas->preco = $request->preco;
        }
        if(isset($request->quantidade_estoque)){
            $vendas->quantidade_estoque = $request->quantidade_estoque;
        }

        $vendas->update();

        return response()->json([
            'status' => true,
            'message' => 'Venda Atualizado',
            'data'=> $vendas
        ]);
    }

    public function destroy($id){
        $vendas = Venda::find($id);

        if($vendas == null){
            return response()->json([
                'status' => false,
                'message' => 'Venda não encontrado'
            ]);
        }

        $vendas->delete();

        return response()->json([
            'status' => true,
            'message' => 'Venda deletado',
            'data'=> $vendas
        ]);
    }

}
