<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class ClienteFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'nome' => 'required|min:3|max:255',
            'email' => 'required|min:10|max:255|unique:clientes,email',
            'telefone' => 'required|max:255|min:5',
            'endereco' => 'required|max:255'
        ];
    }

    protected function failedValidation(Validator $validator)

    {
        throw new HttpResponseException(
            response()->json([
                'status' => false,
                'message' => 'Erro de validação',
                'errors' => $validator->errors()
            ], 422)
        );
    }

    public function messages()
    {
        return [
            'nome.required' => 'O campo nome é obrigatório', 
            'nome.min' => 'O campo nome deve conter no mínimo 03 caracteres',
            'nome.max' => 'O campo nome deve conter no máximo 255 caracteres',

            'email.required' => 'O campo email é obrigatório', 
            'email.min' => 'O campo email deve conter no mínimo 10 caracteres',
            'email.max' => 'O campo email deve conter no máximo 255 caracteres',
            'email.unique' => 'Esse email já está cadastrado',

            'telefone.required' => 'O campo telefone é obrigatório', 
            'telefone.min' => 'O campo telefone deve conter no mínimo 05 caracteres',
            'telefone.max' => 'O campo telefone deve conter no máximo 255 caracteres',

            'endereco.required' => 'O campo endereco é obrigatório', 
            'endereco.max' => 'O campo endereco deve conter no máximo 255 caracteres'
        ];
    }
}
