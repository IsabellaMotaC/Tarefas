<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class ClienteUpdateFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'nome' => 'min:3|max:255',
            'email' => 'max:255|min:10',
            'telefone' => 'max:255|min:4',
            'endereco ' => 'min:4|max:255'
        ];
    }

    protected function failedValidation(Validator $validator)
    
    {
        throw new HttpResponseException(
            response()->json([
                'status' => false,
                'message' => 'Erro de validação',
                'errors' => $validator->errors()
            ], 422));
    }

    public function messages()
    {
        return [
            'nome.min' => 'O campo nome deve conter no mínimo 03 caracteres',
            'nome.max' => 'O campo nome deve conter no máximo 255 caracteres',

            'email.max' =>'O campo email deve conter no máximo 255 caracteres',
            'email.min' =>'O campo email deve conter no mínimo 10 caracteres',

            'telefone.max' => 'O campo telefone deve conter no máximo 255 caracteres',
            'telefone.min' => 'O campo telefone deve conter no mínimo 04 caracteres',

            'endereco.min' => 'O campo endereco deve conter no mínimo 04 caracteres',
            'endereco.max' => 'O campo endereco deve conter no máximo 255 caracteres'
        ];
    }
}
